<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Login</title>
</head>
<body>
<header>
</header>
<div id="content">
<h2>Login to my Website!</h2>
<form action="validation.php" method="post">
<table>
<tr>
<td>Username</td>
<td><input type="text" name="username"/>
</tr>
<tr>
<td>Password</td>
<td><input type="password" name="password"/>
</tr>
<tr>
<td></td>
<td><input type="submit" value="login"/></td>
</tr>
</table>
</form>
    
</div>
</body>
</html>